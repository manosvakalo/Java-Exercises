
public class Game {
	
	

	//atributes
	private final int  rows;
	private final int cols;
	private char[][] table;
	private Player winner;
	
	
	//constructor
	public Game(int r,int c) {
		this.cols= c;
		this.rows = r;
		
		this.table = new char[this.rows][this.cols];
		for(int i=0;i<this.rows;i++) {
			
			for(int j=0;j<this.cols;j++) {
				table[i][j] = '-';
			}
		}
		
	}

	public Player getWinner() {
		return winner;
	}

	public void setWinner(Player winner) {
		this.winner = winner;
	}
	
	
	public void print() {
		System.out.println("BOARD");
		for(int i=0;i<this.rows;i++) {
			System.out.print("| ");
			for(int j=0;j<this.cols;j++) {
				System.out.print(table[i][j]+ " ");
			}
			System.out.println(" |");
		}
		
		//line seperator
		System.out.print("--");
		for(int i=0;i<this.cols;i++)System.out.print("--");
		System.out.print("--\n");
		System.out.print("  ");
		for(int i=0;i<this.cols;i++) {
			System.out.print(i+1 + " ");
		}
		System.out.print("  \n");
		
	}
	
	
	
	//adding chip to table, if column is not full
	public boolean addchip(int pos, char symbol) {
		 // Check if the column number is valid
	    if (pos < 1 || pos > this.cols) {
	        System.out.println("Invalid column. Please select a column between 1 and " + this.cols);
	        return false; 
	    }
		
	    for(int i=this.rows-1;i>=0;i--) {
			if(table[i][pos-1] == '-') {
				this.table[i][pos-1] = symbol;
				return true;
			}
		}
		System.out.println("Not enough space at this column,select other:");
		
		return false;
		}
	
	//checking for 4 chips in row
	public boolean check4indirection(int row, int col, int directrow, int directcol, char symbol) {
		int count = 0;
        for (int i = 0; i < 4; i++) {
            int r = row + i * directrow;
            int c = col + i * directcol;
            if (r >= 0 && r < this.rows && c >= 0 && c < this.cols && table[r][c] == symbol) {
                count++;
            } 
            else break;
            
        }
        return count == 4;
	}
	
	//finding winner
	public boolean checkWin(Player curplayer) {
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.cols; j++) {
                if (check4indirection(i, j, 0, 1, curplayer.getSymbol()) ||  // Οριζόντια νίκη
                		check4indirection(i, j, 1, 0, curplayer.getSymbol()) ||  // Κάθετη νίκη
                		/*check4indirection(i, j, 1, 1, symbol) ||*/  
                		check4indirection(i, j, 1, -1, curplayer.getSymbol())) { // Διαγώνια νίκη
                    /*this.winner.setName(curplayer.getName());
                    this.winner.setSymbol(curplayer.getSymbol());*/
                	this.winner = curplayer;
                	return true;
                }
            }
        }
        return false;
    }
	
	//checking for full table
	public boolean full() {
		int count=0;
		for(int c=0;c<this.cols;c++) {
			if(table[0][c] != '-') count++;
		}
		return count == this.cols;
	}
	
	
}
