import java.util.Scanner;
import java.util.Random;
public class Main {

	public static void main(String[] args) {
		
		System.out.print("Welcome to Score 4 game\n");
		//names and chip set up
		Scanner userInput = new Scanner(System.in);
		char symbol1;
		
		System.out.print("Enter name for 1st player:");
		String playername1 = userInput.nextLine();
		System.out.print("Enter name for 2nd player:");
		String playername2 = userInput.nextLine();
		do {
		System.out.print(playername1 + ",Select your chip:");
		symbol1 = userInput.next().charAt(0);
		if(symbol1 != 'x' && symbol1 != 'o')System.out.println("wrong chip input,try again('x' or 'o'):");
		}while(symbol1 != 'x' && symbol1 != 'o');
		char symbol2 = (symbol1 == 'x') ? 'o' : 'x';
		System.out.println(playername2 + ",your chip is: "+ symbol2);
		
		Player player1 = new Player(playername1,symbol1);
		Player player2 = new Player(playername2,symbol2);
		
		//game set up
		int rows,cols;
		
		//setting dimensions with check
		do {
		System.out.print("Enter number of rows");
		rows = userInput.nextInt();
		if(rows < 4 || rows > 15) System.out.println("Incorrect number of rows(select number between 4 and 15)");
		}while(rows <4 || rows > 15);
		
		do {
			System.out.print("Enter number of cols");
			cols = userInput.nextInt();
			if(cols < 4 || cols > 15) System.out.println("Incorrect number of cols(select number between 4 and 15)");
		}while(cols < 4 || cols > 15);
		
		//setting up board
		Game board = new Game(rows,cols);
		board.print();
		
		//selecting random player to start
		Random random = new Random();
		Player currplayer = random.nextBoolean() ? player1 : player2;
		
		//game playing
		
		while(!board.full() && !board.checkWin(player1) && !board.checkWin(player2)) {
			int position;
			
			System.out.print(currplayer.getName() + ",your turn,select column: ");
			do {
			position = userInput.nextInt();
			}while(!board.addchip(position, currplayer.getSymbol()));
			
			board.print();
			
			//check win
			if(board.checkWin(currplayer)) {
                System.out.println("We have a WINNER!");
                System.out.println(currplayer.getName() + ", Congratulations, you WON!");
                break;
            }
			
			//switching player
			currplayer = (currplayer == player1) ? player2 : player1;
			
			//checking for full board
			if(board.full() && !board.checkWin(player1) && !board.checkWin(player2)) {
	            System.out.println("Board is full, we have a TIE.");
	        }
			
			
			
		}
		
		userInput.close();
		
	}

}

