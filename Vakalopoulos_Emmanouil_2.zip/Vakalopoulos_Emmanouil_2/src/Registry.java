import java.util.ArrayList;
public class Registry {
	
	ArrayList<Suspect> suspects; //suspects in registry
	ArrayList<Communication> comms; //communications
	
	//constructor, initialization of the lists
	public Registry() {
		suspects = new ArrayList<Suspect>();
		comms = new ArrayList<Communication>();
	}
	
	//addSusppect method()
	public void addSuspect(Suspect aSuspect) {
		this.suspects.add(aSuspect);
	}
	
	//addCommunication method()
	public void addCommunication(Communication aCommunication) {
		//locate first suspect using his number
		Suspect sus1=null;
		for(Suspect currSus: suspects) {
			if(currSus.getCriminal_numbers().indexOf(aCommunication.getNum1()) != -1) {
				sus1 = currSus; // locate suspect with number1
				break;
			}
		}
		
		//locate second suspect using his number
		Suspect sus2=null;
		for(Suspect currSus: suspects) {
			if(currSus.getCriminal_numbers().indexOf(aCommunication.getNum2()) != -1) {
				sus2 = currSus; //locate suspect with number2
				break;
			}
		}
		
		//adding associates 
		if(sus1!= null && sus2!= null) {
		sus1.addAssociate(sus2);
		sus2.addAssociate(sus1);
		}
		
	//adding the communication
		this.comms.add(aCommunication);
	}
	
	public Suspect getSuspectWithMostPartners() {
		
		Suspect maxsusp = suspects.get(0); // suspect with most partners -- initialized with the first suspect of the suspect list for ease of maximum find...
		int maxpartners = suspects.get(0).getCocriminals().size(); // list with most cosuspects--> links to the maximum
		
		for(Suspect currsuspect: suspects) {
			if(currsuspect.getCocriminals().size()> maxpartners) {//we check the size of every suspect list
				maxpartners = currsuspect.getCocriminals().size();
				maxsusp = currsuspect;
			}
		}
		
		return maxsusp;
	}
	
	//getLongestCallBetween method()
	public PhoneCall getLongestPhoneCallBetween(String number1 , String number2) {
		int max_duration=0;
		PhoneCall max_call= null;
		
		//locate the call between these numbers from the comms arraylist
		//we search for numbers in both "ends"(if number1 is the sender or the receiver and for number2 the same)
		for(Communication currcall: comms) {
			if(currcall instanceof PhoneCall) {
				//make the communication instaceof PhoneCall for ease of editing
				PhoneCall phonecall = (PhoneCall) currcall;
				if((phonecall.getNum1().equals(number1) && phonecall.getNum2().equals(number2)) ||
						(phonecall.getNum1().equals(number2) && phonecall.getNum2().equals(number1))) {
						if(phonecall.getDuration() > max_duration) {
							max_call = phonecall; // finding max duration
							max_duration = phonecall.getDuration();
						}
				}
			}
		}
		return max_call;
	}
	
	//getMessagesBetween method()
	public ArrayList<SMS> getMessagesBetween(String number1, String number2) {
		ArrayList<SMS> msgs = new ArrayList<SMS>();//adding the contents of messages in list
		for(Communication currcomm : comms) {
			if(currcomm instanceof SMS) {
				//make the communication instaceof SMS for ease of editing
				SMS currmsg = (SMS) currcomm;
				if((currmsg.getNum1().equals(number1) && currmsg.getNum2().equals(number2)) ||
						(currmsg.getNum1().equals(number2) && currmsg.getNum2().equals(number1))) {
					String msg_cont = currmsg.getContent();
					if(msg_cont.contains("Bomb") || msg_cont.contains("Attack") || 
							msg_cont.contains("Explosives") || msg_cont.contains("Gun")) {
						msgs.add(currmsg);
					}
				}
			}
		}
		
		return msgs;
	}

}
