import java.util.ArrayList;
public class Suspect {

	private String name,code_name,city;
	private ArrayList<String> criminal_numbers;
	private ArrayList<Suspect> cocriminals;
	
	public Suspect(String name,String aka, String city) {
		this.name= name;
		this.code_name = aka;
		this.city = city;
		criminal_numbers = new ArrayList<String>();
		cocriminals = new ArrayList<Suspect>();
	}
	
	//addNumber
	public void addNumber(String number) {
		this.criminal_numbers.add(number);
	}
	
	//addAssociate
	public void addAssociate(Suspect associate) {
		boolean found = false;
		
		for(Suspect suspect : cocriminals) {
			if(suspect.getName().equals(associate.getName())) {
				found=true;//checking if associate already exists in suspects list to avoid duplicates
				break;
			}
			
		}
		if(!found)cocriminals.add(associate);
	}
	
	//isConnectedTo
	public boolean isConnectedTo(Suspect associate) {
		for(Suspect suspect : cocriminals) {
			if(suspect.getName().equals(associate.getName())) return true;//searching potential associate in suspects list
		}
		return false;
	}
	
	//getCommonPartners
	public ArrayList<Suspect> getCommonPartners(Suspect aSuspect){
		ArrayList<Suspect> commons = new ArrayList<Suspect>(this.cocriminals);//criminals associates put in new list commons
		ArrayList<Suspect> asusp_partners = new ArrayList<Suspect>(aSuspect.getCocriminals());//aSuspects associates
		commons.retainAll(asusp_partners);//finding the commons between the two lists
		return commons;
	}
	
	//print associates info
	public void printAssociateInfo() {
		System.out.println("Potential Associates Info:");
		for(Suspect suspect : cocriminals) {
			System.out.print("Name: "+ suspect.getName()+"\n");
			System.out.print("Code Name: "+ suspect.getCodeName()+"\n");
			
		}
	}
	
	//Setters and Getters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCodeName() {
		return this.code_name;
	}

	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	public ArrayList<String> getCriminal_numbers() {
		return criminal_numbers;
	}

	public void setCriminal_numbers(ArrayList<String> criminal_numbers) {
		this.criminal_numbers = criminal_numbers;
	}

	public ArrayList<Suspect> getCocriminals() {
		return cocriminals;
	}

	public void setCocriminals(ArrayList<Suspect> cocriminals) {
		this.cocriminals = cocriminals;
	}

	public String getCode_name() {
		return code_name;
	}
	
}
