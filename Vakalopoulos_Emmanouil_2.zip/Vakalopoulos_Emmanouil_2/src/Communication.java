
public abstract class Communication {

	private String num1,num2;
	private int dd,mm,yy;
	
	public Communication(String anum1,String anum2, int add,int amm, int ayy) {
		this.num1 = anum1;
		this.num2 = anum2;
		this.dd = add;
		this.mm = amm;
		this.yy = ayy;
	}
	
	public abstract void printInfo();

	//setters and getters
	public String getNum1() {
		return num1;
	}

	public void setNum1(String num1) {
		this.num1 = num1;
	}

	public String getNum2() {
		return num2;
	}

	public void setNum2(String num2) {
		this.num2 = num2;
	}

	public int getDd() {
		return dd;
	}

	public void setDd(int dd) {
		this.dd = dd;
	}

	public int getMm() {
		return mm;
	}

	public void setMm(int mm) {
		this.mm = mm;
	}

	public int getYy() {
		return yy;
	}

	public void setYy(int yy) {
		this.yy = yy;
	}
	
	
}
