
public class PhoneCall extends Communication {
	private int duration;
	
	public PhoneCall(String anum1,String anum2, int add,int amm, int ayy,int dur) {
		super(anum1,anum2,add,amm,ayy);
		this.duration = dur;
	}
	
	public void printInfo() {
		System.out.println("This phone call has the following info");
		System.out.println("Between "+ super.getNum1() +"---"+ super.getNum2());
		System.out.println("on "+super.getYy() +"/" +super.getMm() +"/" +super.getDd());
		System.out.println("Duration: "+ this.duration);
	}

	//setters and getters
	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

}
