
public class SMS extends Communication {
	private String content;
	
	public SMS(String anum1,String anum2, int add,int amm, int ayy,String conts) {
		super(anum1,anum2,add,amm,ayy);
		this.content = conts;
	}
	public void printInfo() {
		System.out.println("This SMS has the following info");
		System.out.println("Between "+ super.getNum1() +"---"+ super.getNum2());
		System.out.println("on "+super.getYy() +"/" +super.getMm() +"/" +super.getDd());
		System.out.println("text: "+ this.content);
	}
	
	//setters and getters
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
